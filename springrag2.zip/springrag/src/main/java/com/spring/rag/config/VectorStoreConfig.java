package com.spring.rag.config;

import com.spring.rag.utils.FileUtils;
import com.spring.rag.utils.ProcessedFilesTracker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TextSplitter;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Configuration
public class VectorStoreConfig {

    @Bean
    public SimpleVectorStore simpleVectorStore(EmbeddingModel embeddingModel, VectorStoreProperties vectorStoreProperties) {
        SimpleVectorStore store = SimpleVectorStore.builder(embeddingModel).build();
        File vectorStoreFile = new File(vectorStoreProperties.getVectorStorePath());
        File metadataFile = new File(vectorStoreProperties.getVectorStorePath() + ".metadata");

        // Load existing vector store and metadata
        if (vectorStoreFile.exists()) {
            store.load(vectorStoreFile);
            loadProcessedFilesMetadata(metadataFile);
        } else {
            ProcessedFilesTracker.setProcessedFiles(new ArrayList<>());
            // Load initial documents only if documentsToLoad is not null and not empty
            List<Document> allSplitDocs = new ArrayList<>();
            List<Resource> documentsToLoad = vectorStoreProperties.getDocumentsToLoad();
            if (documentsToLoad != null && !documentsToLoad.isEmpty()) {
                documentsToLoad.forEach(document -> {
                    TikaDocumentReader documentReader = new TikaDocumentReader(document);
                    List<Document> docs = documentReader.get();
                    String filename = document.getFilename();
                    try {
                        String hash = FileUtils.computeMd5Hash(document.getInputStream());
                        for (Document doc : docs) {
                            doc.getMetadata().put("filename", filename);
                            doc.getMetadata().put("fileHash", hash);
                        }
                        ProcessedFilesTracker.addProcessedFile(filename, hash);
                        TextSplitter textSplitter = new TokenTextSplitter();
                        List<Document> splitDocs = textSplitter.apply(docs);
                        allSplitDocs.addAll(splitDocs);
                    } catch (IOException e) {
                        log.error("Failed to compute hash for document: {}", filename, e);
                    }
                });
                if (!allSplitDocs.isEmpty()) {
                    store.add(allSplitDocs);
                    store.save(vectorStoreFile);
                    saveProcessedFilesMetadata(metadataFile);
                }
            } else {
                log.info("No initial documents to load; vector store will be empty until files are uploaded.");
            }
        }

        return store;
    }

    private void loadProcessedFilesMetadata(File metadataFile) {
        if (metadataFile.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(metadataFile))) {
                Map<String, String> fileHashes = (Map<String, String>) ois.readObject();
                ProcessedFilesTracker.setProcessedFilesFromMap(fileHashes);
                log.info("Loaded processed files metadata from {}", metadataFile.getAbsolutePath());
            } catch (IOException | ClassNotFoundException e) {
                log.error("Failed to load processed files metadata", e);
                ProcessedFilesTracker.setProcessedFiles(new ArrayList<>());
            }
        } else {
            ProcessedFilesTracker.setProcessedFiles(new ArrayList<>());
        }
    }

    private void saveProcessedFilesMetadata(File metadataFile) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(metadataFile))) {
            oos.writeObject(ProcessedFilesTracker.getProcessedFiles());
            log.info("Saved processed files metadata to {}", metadataFile.getAbsolutePath());
        } catch (IOException e) {
            log.error("Failed to save processed files metadata", e);
        }
    }
}