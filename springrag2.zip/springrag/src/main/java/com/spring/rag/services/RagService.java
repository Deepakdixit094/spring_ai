package com.spring.rag.services;

import com.spring.rag.dto.ApiResponse;
import com.spring.rag.dto.RequestClass;
import com.spring.rag.model.Answer;
import org.springframework.stereotype.Component;

@Component
public interface RagService {

    ApiResponse<Answer> getAnswerFromRag(RequestClass requestClass);
}