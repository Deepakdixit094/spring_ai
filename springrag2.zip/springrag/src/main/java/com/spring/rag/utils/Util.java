package com.spring.rag.utils;


import org.apache.tika.Tika;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.ai.document.Document;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;

public class Util {

    private static final Set<String> DOCUMENT_EXTENSIONS = new HashSet<>(Arrays.asList("txt", "doc", "docx", "pdf", "rtf", "odt", "xls", "xlsx", "ppt", "pptx", "csv"));

    private static final Tika tika = new Tika();

    public static List<Document> extractContent(MultipartFile file) {
        try (InputStream inputStream = file.getInputStream()) {
            BodyContentHandler handler = new BodyContentHandler(-1);
            Metadata metadata = new Metadata();
            AutoDetectParser parser = new AutoDetectParser();
            ParseContext context = new ParseContext();

            parser.parse(inputStream, handler, metadata, context);

            String extractedText = handler.toString();

            // Split content into chunks of around 500 characters (adjust as needed)
            List<Document> documentChunks = new ArrayList<>();
            int chunkSize = 500;
            for (int i = 0; i < extractedText.length(); i += chunkSize) {
                String chunk = extractedText.substring(i, Math.min(i + chunkSize, extractedText.length()));
                documentChunks.add(new Document(chunk));
            }

            return documentChunks;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }


    public static String getFileExtension(MultipartFile file) {
        if (file == null || file.getOriginalFilename() == null) {
            return "";
        }

        String fileName = file.getOriginalFilename();
        int lastIndex = fileName.lastIndexOf('.');
        if (lastIndex == -1 || lastIndex == fileName.length() - 1) {
            // No extension or the dot is at the end
            return "";
        }

        return fileName.substring(lastIndex + 1).toLowerCase();
    }

    public static boolean isDocumentExtension(String extension) {
        if (extension == null || extension.isEmpty()) {
            return false;
        }
        return DOCUMENT_EXTENSIONS.contains(extension.toLowerCase());
    }


}
