package com.spring.rag.utils;

import org.springframework.ai.document.Document;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProcessedFilesTracker {
    private static Map<String, String> fileHashes = new HashMap<>(); // filename to hash

    public static void addProcessedFile(String filename, String hash) {
        fileHashes.put(filename, hash);
    }

    public static boolean isFileProcessed(String filename, String hash) {
        String storedHash = fileHashes.get(filename);
        return storedHash != null && storedHash.equals(hash);
    }

    public static void setProcessedFiles(List<Document> documents) {
        Map<String, String> newFileHashes = new HashMap<>();
        for (Document doc : documents) {
            String filename = (String) doc.getMetadata().get("filename");
            String fileHash = (String) doc.getMetadata().get("fileHash");
            if (filename != null && fileHash != null) {
                newFileHashes.put(filename, fileHash);
            }
        }
        fileHashes = newFileHashes;
    }

    public static void setProcessedFilesFromMap(Map<String, String> map) {
        fileHashes = new HashMap<>(map);
    }

    public static Map<String, String> getProcessedFiles() {
        return new HashMap<>(fileHashes); // Return a copy to avoid external modification
    }
}