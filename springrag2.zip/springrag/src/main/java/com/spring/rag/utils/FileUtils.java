package com.spring.rag.utils;

import org.springframework.util.DigestUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

public class FileUtils {
    // For MultipartFile (used in RagServiceImpl)
    public static String computeMd5Hash(MultipartFile file) throws IOException {
        return DigestUtils.md5DigestAsHex(file.getInputStream());
    }

    // For InputStream (used in VectorStoreConfig)
    public static String computeMd5Hash(InputStream inputStream) throws IOException {
        return DigestUtils.md5DigestAsHex(inputStream);
    }
}