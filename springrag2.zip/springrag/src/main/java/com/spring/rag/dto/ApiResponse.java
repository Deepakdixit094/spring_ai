package com.spring.rag.dto;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatusCode;

@Setter
@Getter
public class ApiResponse<T> {
    // Getters and Setters
    private HttpStatusCode status;
    private String message;
    private T data;

    // Constructor for responses with data
    public ApiResponse(HttpStatusCode status, String message, T data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    // Constructor for responses without data
    public ApiResponse(HttpStatusCode status, String message) {
        this(status, message, null);
    }

    // Static factory methods for common responses
    public static <T> ApiResponse<T> success(String message, T data) {
        return new ApiResponse<>(HttpStatusCode.valueOf(200), message, data);
    }

    public static <T> ApiResponse<T> success(String message) {
        return success(message, null);
    }

    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(HttpStatusCode.valueOf(500), message);
    }

    public static <T> ApiResponse<T> notFound(String message) {
        return new ApiResponse<>(HttpStatusCode.valueOf(404), message);
    }

    public static <T> ApiResponse<T> badRequest(String message) {
        return new ApiResponse<>(HttpStatusCode.valueOf(400), message);
    }
}
