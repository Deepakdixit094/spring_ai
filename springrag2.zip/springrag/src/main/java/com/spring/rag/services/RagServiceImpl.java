package com.spring.rag.services;

import com.spring.rag.config.VectorStoreProperties;
import com.spring.rag.dto.ApiResponse;
import com.spring.rag.dto.RequestClass;
import com.spring.rag.model.Answer;
import com.spring.rag.model.Question;
import com.spring.rag.utils.FileUtils;
import com.spring.rag.utils.ProcessedFilesTracker;
import com.spring.rag.utils.Util;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.document.Document;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class RagServiceImpl implements RagService {

    private final OllamaChatModel chatModel;
    private final SimpleVectorStore vectorStore;
    private final Resource ragPromptTemplate;
    private final VectorStoreProperties vectorStoreProperties;
    private final File uploadsDir;

    public RagServiceImpl(OllamaChatModel chatModel, SimpleVectorStore vectorStore,
                          @Value("classpath:/templates/rag-prompt-template.st") Resource ragPromptTemplate,
                          VectorStoreProperties vectorStoreProperties) {
        this.chatModel = chatModel;
        this.vectorStore = vectorStore;
        this.ragPromptTemplate = ragPromptTemplate;
        this.vectorStoreProperties = vectorStoreProperties;

        String uploadsPath = System.getProperty("java.io.tmpdir") + File.separator + "rag_uploads";
        if (vectorStoreProperties.getUploadsDir() != null && !vectorStoreProperties.getUploadsDir().isEmpty()) {
            uploadsPath = vectorStoreProperties.getUploadsDir();
        }
        this.uploadsDir = new File(uploadsPath);
        if (!uploadsDir.exists()) {
            boolean created = uploadsDir.mkdirs();
            if (!created) {
                throw new IllegalStateException("Failed to create uploads directory: " + uploadsPath);
            }
        }
        log.info("Uploads directory initialized at: {}", uploadsDir.getAbsolutePath());
    }

    @SneakyThrows
    @Override
    public ApiResponse<Answer> getAnswerFromRag(RequestClass requestClass) {
        log.info("Inside the getAnswerFromRag method()");
        MultipartFile file = requestClass.getFile();
        Question question = requestClass.getQuestion();

        if (file != null && !file.isEmpty()) {
            String filename = file.getOriginalFilename();
            String currentHash = FileUtils.computeMd5Hash(file);

            if (ProcessedFilesTracker.isFileProcessed(filename, currentHash)) {
                log.info("File {} already processed with the same content, skipping.", filename);
            } else {
                String fileExtension = Util.getFileExtension(file);
                if (!Util.isDocumentExtension(fileExtension)) {
                    throw new IllegalArgumentException("Unsupported file type: " + fileExtension);
                }

                String filePath = uploadsDir.getAbsolutePath() + File.separator + filename;
                File dest = new File(filePath);
                file.transferTo(dest);

                FileSystemResource resource = new FileSystemResource(dest);
                TikaDocumentReader documentReader = new TikaDocumentReader(resource);
                List<Document> docs = documentReader.get();

                for (Document doc : docs) {
                    doc.getMetadata().put("filename", filename);
                    doc.getMetadata().put("fileHash", currentHash);
                }

                TokenTextSplitter textSplitter = new TokenTextSplitter();
                List<Document> splitDocs = textSplitter.apply(docs);
                vectorStore.add(splitDocs);

                File vectorStoreFile = new File(vectorStoreProperties.getVectorStorePath());
                vectorStore.save(vectorStoreFile);

                ProcessedFilesTracker.addProcessedFile(filename, currentHash);
                saveProcessedFilesMetadata(new File(vectorStoreProperties.getVectorStorePath() + ".metadata"));
                log.info("File {} processed and added to vector store", filename);
            }
        }

        List<Document> documents = vectorStore.similaritySearch(SearchRequest.builder()
                .query(question.getQuestion()).topK(5).build());
        List<String> contentList = documents.stream().map(Document::getContent).toList();

        PromptTemplate promptTemplate = new PromptTemplate(ragPromptTemplate);
        Prompt prompt = promptTemplate.create(Map.of("input", question.getQuestion(), "documents",
                String.join("\n", contentList)));

        contentList.forEach(System.out::println);

        ChatResponse response = chatModel.call(prompt);

        Answer answer = new Answer(response.getResult().getOutput().getContent());

        return new ApiResponse<>(HttpStatus.OK, "Success", answer);
    }

    private void saveProcessedFilesMetadata(File metadataFile) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(metadataFile))) {
            oos.writeObject(ProcessedFilesTracker.getProcessedFiles());
            log.info("Saved processed files metadata to {}", metadataFile.getAbsolutePath());
        } catch (IOException e) {
            log.error("Failed to save processed files metadata", e);
        }
    }
}