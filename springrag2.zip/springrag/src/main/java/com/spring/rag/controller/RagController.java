package com.spring.rag.controller;

import com.spring.rag.dto.ApiResponse;
import com.spring.rag.dto.RequestClass;
import com.spring.rag.model.Answer;
import com.spring.rag.model.Question;
import com.spring.rag.services.RagService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


@RestController
public class RagController {

    private final RagService ragService;

    public RagController(RagService ragService) {
        this.ragService = ragService;
    }

    @PostMapping(value = "/ask")
    public ResponseEntity<ApiResponse<Answer>> askQuestion(@RequestParam("question") Question question, @RequestParam("file") MultipartFile file) {

        RequestClass requestClass = RequestClass.builder().question(question).file(file).build();
        ApiResponse<Answer> answerFromRag = this.ragService.getAnswerFromRag(requestClass);
        return new ResponseEntity<>(answerFromRag, answerFromRag.getStatus());

    }


}



