package com.spring.rag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringragApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringragApplication.class, args);
	}

}
