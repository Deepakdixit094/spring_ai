package com.spring.rag.dto;

import com.spring.rag.model.Question;
import lombok.*;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RequestClass {

    private Question question;

    private MultipartFile file;

}
